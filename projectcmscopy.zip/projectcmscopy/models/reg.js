const mongoose=require('mongoose')//module


const regSchema=mongoose.Schema({
    email:String,
    password:String,
    firstname:String,
    lastname:String,
    mobile:Number,
    desc:String,
    img:{type:String,default:'default.png'},
    status:{type:String,default:'unverified'},
    role:{type:String,default:'public'}
})



module.exports=mongoose.model('reg',regSchema)